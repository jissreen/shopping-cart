var person={name:"jis",age:29,place:"uae"}
for(x in person)
{
    console.log(person[x])
}