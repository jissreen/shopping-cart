var dt=new Date()
console.log('hello')
for(i=0;i<100;i++){
    console.log('Loop')
}
console.log('end')
var diff=new Date()-dt
console.log(diff)
