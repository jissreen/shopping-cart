var a=30
var b=70
console.log(a+b)